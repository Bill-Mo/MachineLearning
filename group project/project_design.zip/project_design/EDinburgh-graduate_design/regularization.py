from sklearn.model_selection import KFold
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
from preprocessing import preprocessing
import matplotlib.pyplot as plt
ncomp = 40

x_train, x_test, y_train, y_test = preprocessing(ncomp)

X = np.concatenate((x_train, x_test))
y = np.concatenate((y_train, y_test))

nfold = 5
kf = KFold(n_splits=nfold, shuffle=True)
n_alpha = 20
alpha_test = np.logspace(-2, 2, n_alpha)
r2s = np.zeros((nfold, n_alpha))

for it, a in enumerate(alpha_test): 
    for isplit, Ind in enumerate(kf.split(X)): 
        Itr, Its = Ind
        Xtr_iter, Xts_iter = X[Itr], X[Its]
        Ytr_iter, Yts_iter = y[Itr], y[Its]
        regr = Ridge(a).fit(Xtr_iter, Ytr_iter)
        yhat = regr.predict(Xts_iter)
        r2s[isplit, it] = r2_score(Yts_iter, yhat)

r2_mean = np.mean(r2s, axis=0)
r2_std = np.std(r2s, axis=0) / np.sqrt(nfold-1)
plt.errorbar(alpha_test, r2_mean, yerr=r2_std, fmt='-')
plt.xlabel('alpha')
plt.ylabel('R^2')
plt.grid()
plt.show()

print(np.argmax(r2_mean), max(r2_mean))